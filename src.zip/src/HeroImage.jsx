import * as React from "react";

function HeroImage() {
  return (
    <div className="coffee-container">
      <div className="text-overlay">
        Your Mornings <br /> Just got Better
      </div>
    </div>
  );
}

export default HeroImage;